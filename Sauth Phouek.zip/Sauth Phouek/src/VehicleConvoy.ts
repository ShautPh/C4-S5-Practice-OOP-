import { Vehicle } from "./Vehicle";
export class VehicleConvoy {
    private vehicles: Vehicle[] = [];

    addVehicle(...vehicle:Vehicle[]){
        this.vehicles = this.vehicles.concat(vehicle);
    }
    getMaxSpeed():number{
        let maxSpeed = this.vehicles[0].getSpeed();
        this.vehicles.forEach(vehicle=>{
            if (vehicle.getSpeed() < maxSpeed){
                maxSpeed = vehicle.getSpeed();
            }
        })
        return maxSpeed;
    }
}