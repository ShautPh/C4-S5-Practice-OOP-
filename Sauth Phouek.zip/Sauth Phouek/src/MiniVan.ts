import { Vehicle } from "./Vehicle";

export class MiniVan extends Vehicle{
    private passenger : number;
    private luggage : number;
    constructor(customer:number, luggage:number, plateId:string, weight:number){
        super(plateId,weight);
        this.passenger = customer;
        this.luggage = luggage;
    }
    numberCustomers():number{
        return this.passenger;
    }

    numberLuggage():number{
        return this.luggage;
    }
    getSpeed(): number {
        return 130 - (this.numberCustomers()*10 + this.numberLuggage()*5);
        
    }

    

}