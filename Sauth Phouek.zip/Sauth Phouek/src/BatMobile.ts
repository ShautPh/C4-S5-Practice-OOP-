import { Vehicle } from "./Vehicle"

export class BatMobile extends Vehicle {
    private isBatManHere: boolean;
    constructor(isBatManHere:boolean, plateId:string, weight:number) {
        super(plateId, weight);
        this.isBatManHere = isBatManHere;
    }
    getSpeed(): number {
        if (this.isBatManHere){
            return 500;
        }
        return 110;
    }
}