import { Vehicle } from "./Vehicle";

export class TucTuc extends Vehicle{
    private passenger:number
    constructor (passenger:number,plateId:string, weight:number){
        super(plateId,weight)
        this.passenger = passenger;
    }

    numberCustomers():number{
        return this.passenger;
    }

    getSpeed(): number {
        return 130 - this.numberCustomers()*5;
    }
}