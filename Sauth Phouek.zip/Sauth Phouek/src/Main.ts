import { BatMobile } from "./BatMobile";
import { MiniVan } from "./MiniVan";
import { TucTuc } from "./TucTuc";
import { VehicleConvoy } from "./VehicleConvoy";

let batMobile = new BatMobile(true,'Kampong Thom 3A-0879', 300);
batMobile.getSpeed();

let miniVan = new MiniVan(5, 6, 'Siem Reap 3C-4860', 600);
miniVan.getSpeed();

let toktok = new TucTuc(5,'Phnom Penh 2AF-1622', 250);
toktok.getSpeed();

let convoy = new VehicleConvoy();
convoy.addVehicle(batMobile,miniVan,toktok);
console.log(convoy);
console.log("The maximum speed is: " + convoy.getMaxSpeed() + "km/h");



