export abstract class Vehicle {
    constructor(private plateId: string , private weight:number) {
        
    }

    abstract getSpeed():number;
    
}